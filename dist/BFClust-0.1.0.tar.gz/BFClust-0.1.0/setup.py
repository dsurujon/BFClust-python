from setuptools import setup

setup(
    name = 'BFClust',
    version = '0.1.0',
    description = 'Boundary Forest Clustering',
    url = 'https://github.com/dsurujon/BFClust-python',
    author = 'Defne Surujon',
    author_email = 'defnesurujon@gmail.com',
    packages = ['BFClust'],
    install_requires = ['numpy', 'pandas', 'joblib', 'scikit-learn', 'biopython']
)